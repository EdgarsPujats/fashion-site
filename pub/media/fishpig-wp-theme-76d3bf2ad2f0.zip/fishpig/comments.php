<?php
/*
 *
 */
// phpcs:ignoreFile -- this file is a WordPress theme file and will not run in Magento